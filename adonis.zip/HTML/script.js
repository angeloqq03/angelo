const cannedMessages = {
  greetings: [
    "Hi, I'm your chatbot assistant. How can I assist you?",
    "Hello there! I'm your chatbot support. How can I be of assistance?"
  ],
  how: [
    "What about you?",
    "Is there anything specific you'd like to know?"
  ],
  why: [
    "I'm not entirely sure. It depends on the context.",
    "That's a good question. It could have various reasons."
  ],
  what: [
    "Could you provide more context for your question?",
    "What aspect are you referring to exactly?"
  ],
  when: [
    "It's difficult to say without more information.",
    "The timing depends on various factors."
  ],
};

const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');

let canChat = true;

function sMsg() {
  if (!canChat) return;

  const message = userInput.value.trim().toLowerCase();
  disUmsg(message);
  setTimeout(() => {
    disBtyp();
    setTimeout(() => {
      disresP(message);
    }, 1500);
  }, 500);
  userInput.value = '';
  canChat = false;
  sendButton.disabled = true;
  setTimeout(() => {
    canChat = true;
    sendButton.disabled = false;
  }, 1000);
}

function disUmsg(message) {
  const messageElement = document.createElement('div');
  messageElement.textContent = message;
  messageElement.classList.add('user-message');
  chatBox.appendChild(messageElement);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function disBtyp() {
  const typingElement = document.createElement('div');
  
  typingElement.classList.add('bot-message', 'typing-animation');
  chatBox.appendChild(typingElement);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function disresP(message) {
  const responseType = getMtyp(message);
  const response = cannedMessages[responseType][Math.floor(Math.random() * cannedMessages[responseType].length)];
  
  const typingElement = chatBox.querySelector('.typing-animation');
  if (typingElement) {
    chatBox.removeChild(typingElement);
  }
  
  const messageElement = document.createElement('div');
  messageElement.textContent = response;
  messageElement.classList.add('bot-message');
  chatBox.appendChild(messageElement);
  chatBox.scrollTop = chatBox.scrollHeight;
  setTimeout(() => {
    messageElement.style.opacity = 1;
  }, 500);
}

function getMtyp(message) {
  if (message.includes('how')) {
    return 'how';
  } else if (message.includes('why')) {
    return 'why';
  } else if (message.includes('what')) {
    return 'what';
  } else if (message.includes('when')) {
    return 'when';
  } else {
    return 'greetings';
  }
}
